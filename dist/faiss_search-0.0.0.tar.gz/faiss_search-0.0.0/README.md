# faiss-search
Tool designed to create the embedding and FAISS search pipeline
